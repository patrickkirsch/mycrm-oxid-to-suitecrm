<?php 

$mod_strings['LBL_OXID_C'] = 'Oxid ID';   


?>