<?PHP
$mod_strings['LBL_VAT_ID_C'] ="VAT Number"; 
$mod_strings['LBL_OXID_NEWSLETTER_C'] = 'OXID Newsletter';     

?>