<?php
// created: 2009-07-21 12:06:15
$dictionary["Opportunity"]["fields"]["mycrm_products_opportunities"] = array (
  'name' => 'mycrm_products_opportunities',
  'type' => 'link',
  'relationship' => 'mycrm_products_opportunities',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-07-21 13:07:10
$dictionary["Opportunity"]["fields"]["mycrm_products_opportunities"] = array (
  'name' => 'mycrm_products_opportunities',
  'type' => 'link',
  'relationship' => 'mycrm_products_opportunities',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-07-21 13:42:01
$dictionary["Opportunity"]["fields"]["mycrm_products_opportunities"] = array (
  'name' => 'mycrm_products_opportunities',
  'type' => 'link',
  'relationship' => 'mycrm_products_opportunities',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-07-24 11:18:08
$dictionary["Opportunity"]["fields"]["mycrm_products_opportunities"] = array (
  'name' => 'mycrm_products_opportunities',
  'type' => 'link',
  'relationship' => 'mycrm_products_opportunities',
  'source' => 'non-db',
);
?>
