<?php
$mod_strings['LBL_OXSEND_FROM_SUGAR_TO_OXID'] ="Send data from Sugar to Oxid:"; 
$mod_strings['LBL_OXCONFLICT_RESOLUTION'] ="Conflict resolution:"; 
$mod_strings['LBL_OXSUGAR_WINS'] ="Sugar wins"; 
$mod_strings['LBL_OXOXID_WINS'] ="Oxid wins"; 
$mod_strings['LBL_OXOPPORTUNITY_ACC'] ="Default Opportunity Account:"; 
$mod_strings['LBL_OXCONFLICT_EMAIL'] ="Send conflict alert to mail:"; 
$mod_strings['LBL_OXOXID_URL'] ="Oxid URL:"; 
$mod_strings['LBL_OXOXID_USRNAME'] ="Oxid username:"; 
$mod_strings['LBL_OXOXID_SRV_SETTINGS'] ="Oxid server settings"; 
$mod_strings['LBL_OXSYNC_DIRECTION'] ="Sync direction";                                 
$mod_strings['LBL_OXUPDT_TO_OXID'] ="Update to Oxid changed data in Sugar.";   
$mod_strings['LBL_OXCONF_WHO_WINS'] ="In case of conflict who wins.";   
$mod_strings['LBL_OXRELATED_OPP_ACC'] ="Opportunities related to Oxid orders will be related to this account.";
$mod_strings['LBL_OXCONF_EMAIL_TOSEND'] ="E-mail to send report to.";
$mod_strings['SUGAROXID_LINK_EDIT']="Oxid Connection";

?>