<?PHP
/************************************************

MyCRM OXID-to-Sugar Connector

The Program is provided AS IS, without warranty. You can redistribute it and/or modify it under the terms of the GNU Affero General Public License Version 3 as published by the Free Software Foundation.

For contact:
MyCRM GmbH
Hirschlandstrasse 150
73730 Esslingen
Germany

www.mycrm.de
info@mycrm.de

****************************************************/
require_once('modules/MyCRM_Products/MyCRM_Products_sugar.php');
class MyCRM_Products extends MyCRM_Products_sugar {
	
	function MyCRM_Products(){	
		parent::MyCRM_Products_sugar();
	}
	
}
?>