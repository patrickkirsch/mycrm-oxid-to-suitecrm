<?php 
 //WARNING: The contents of this file are auto-generated



    
$mod_strings['LBL_OXID_SETTINGS']="Oxid Connector Settings";    
$mod_strings['LBL_OXID_CONNECTION_SETTINGS']="Oxid";  

$mod_strings['LBL_OXSEND_FROM_SUGAR_TO_OXID'] ="Send data from Sugar to Oxid:"; 
$mod_strings['LBL_OXCONFLICT_RESOLUTION'] ="Conflict resolution:"; 
$mod_strings['LBL_OXSUGAR_WINS'] ="Sugar wins"; 
$mod_strings['LBL_OXOXID_WINS'] ="Oxid wins"; 
$mod_strings['LBL_OXOPPORTUNITY_ACC'] ="Default Opportunity Account:"; 
$mod_strings['LBL_OXCONFLICT_EMAIL'] ="Send conflict alert to mail:"; 
$mod_strings['LBL_OXOXID_URL'] ="Oxid URL:"; 
$mod_strings['LBL_OXOXID_USRNAME'] ="Username:"; 
$mod_strings['LBL_OXOXID_SRV_SETTINGS'] ="Oxid server settings"; 
$mod_strings['LBL_OXSYNC_DIRECTION'] ="Sync direction";                                 
$mod_strings['LBL_OXUPDT_TO_OXID'] ="Check to send updates in Sugar accounts & Contacts records to OXID eSales. Currently only a small selection of fields are supported.";   
$mod_strings['LBL_OXCONF_WHO_WINS'] ="Set who wins in case in between the snyc periods the value changes on both sides.";   
$mod_strings['LBL_OXRELATED_OPP_ACC'] ="Select the account to relate to when system creates a contact in Sugar after a buy. Example: \"Dummy Account for Consumers\".";
$mod_strings['LBL_OXCONF_EMAIL_TOSEND'] ="Enter the email address where notifications shall be sent in case of sync conflicts.";
$mod_strings['SUGAROXID_LINK_EDIT']="Oxid Connection";
$mod_strings['LBL_OXOXID_PASS']="Password"; 





?>