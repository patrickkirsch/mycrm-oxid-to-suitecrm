<?php 
 //WARNING: The contents of this file are auto-generated




global $theme;  
$theme_path="themes/".$theme."/";
$image_path=$theme_path."images/";


$admin_option_defs=array();
$admin_option_defs['Accounts']['settings']= 
            array('themes/default/images/ConfigureTabs',
            'LBL_OXID_SETTINGS',
            '',
            './index.php?module=Administration&action=DetailViewOxidSync');
$admin_group_header[]= array('LBL_OXID_CONNECTION_SETTINGS','',false,$admin_option_defs); 



?>